// Importing required JavaFX classes
package com.example;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;
import javafx.scene.control.ColorPicker;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import java.util.ArrayList;

// Defining the class that extends Application
public class guiAssignment3_200534772 extends Application {

    // Initializing an ArrayList to keep track of chosen colors
    private ArrayList<String> chosenColors = new ArrayList<>();

    // Method to display an error message using an Alert
    private void showErrorAlert(String message, Node owner) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message);
        alert.initOwner(owner.getScene().getWindow());
        alert.showAndWait();
    }

    // Overriding the start method of the Application class
    @Override
    public void start(Stage primaryStage) {

        // Creating a new GridPane to display the seating arrangement
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        // Creating a Text object to display the heading
        Text heading = new Text("Teacher");
        heading.setFont(Font.font("Arial", 20));
        heading.setFill(Color.BLACK);

        // Looping through each seat and adding a Rectangle object to the GridPane
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                Rectangle seat = new Rectangle(40, 40, Color.WHITE);
                gridPane.add(seat, col, row);
            }
        }

        // Creating a new VBox to display the input fields and button
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(10));
        vbox.setAlignment(Pos.CENTER);

        // Creating a Label and TextField for the student name input
        Label nameLabel = new Label("Name:");
        TextField nameTextField = new TextField();
        HBox nameBox = new HBox(10, nameLabel, nameTextField);

        // Creating a Label and ColorPicker for the student color input
        Label colorLabel = new Label("Color:");
        ColorPicker colorPicker = new ColorPicker();
        HBox colorBox = new HBox(10, colorLabel, colorPicker);

        // Creating a Button to add a new student to the seating arrangement
        Button addButton = new Button("Add Student");
        addButton.setOnAction(event -> { // sets an event handler for the button
            String name = nameTextField.getText().trim(); // gets the name entered by the user
            Color studentColor = colorPicker.getValue(); // gets the color selected by the user

            // checks if the name field is empty
            if (name.isEmpty()) {
                showErrorAlert("Please enter a name.", addButton); // shows an error message
            }
            // checks if the color has already been chosen by another student
            else if (chosenColors.contains(studentColor.toString())) {
                showErrorAlert("Please choose another color because that color has already been chosen.", addButton); // shows
                                                                                                                      // an
                                                                                                                      // error
                                                                                                                      // message
            }
            // if the name and color are valid, finds the first available seat and assigns
            // it to the student
            else {
                boolean seatFound = false;
                for (int row = 0; row < 3 && !seatFound; row++) {
                    for (int col = 0; col < 3 && !seatFound; col++) {
                        Rectangle seat = (Rectangle) gridPane.getChildren().get(row * 3 + col); // gets the seat at the
                                                                                                // current row and
                                                                                                // column
                        if (seat.getFill().equals(Color.WHITE)) { // checks if the seat is available
                            seat.setFill(studentColor); // assigns the color to the seat
                            Text nameText = new Text(name); // creates a text object with the student's name
                            nameText.setFill(studentColor.invert()); // sets the text color to the inverse of the seat
                                                                     // color
                            gridPane.add(nameText, col, row); // adds the name to the grid at the current row and column
                            seatFound = true; // sets the seatFound flag to true
                        }
                    }
                }

                // if no seat is available, shows an error message
                if (!seatFound) {
                    showErrorAlert("No more seats available.", addButton);
                }
                // otherwise, adds the chosen color to the list of chosen colors
                else {
                    chosenColors.add(studentColor.toString());
                }
            }
        });

        // adds the GUI components to a vertical box
        vbox.getChildren().addAll(heading, nameBox, colorBox, addButton);

        // creates the scene with a grid pane and the vertical box, and sets the size of
        // the scene
        Scene scene = new Scene(new VBox(gridPane, vbox), 300, 400);

        // sets the scene to the primary stage and displays it
        primaryStage.setScene(scene);
        primaryStage.show();

        // sets the primary stage to always be on top of other windows
        primaryStage.setAlwaysOnTop(true);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
